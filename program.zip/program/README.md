# Medialogi-P3-02
3rd semester Medialogy project

"How can we make a training assistant program which counts a given exercise the user has performed, with minimal equipment requirements using computer vision?"

Deadline: 20. December 2021

Group members:
- Kristian
- Sebastian
- Rebecca
- Tobias
- Charlotte
- Tonko