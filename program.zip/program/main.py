import UIWithoutVideoFeed


# Main function running the live video from standard camera in users computer
# Running image processing and movement and/or color detection.
# Counts the amount of squats made by the user and shows it in the display.
def main():
    UIWithoutVideoFeed.make_frame()

if __name__ == '__main__':
    main()